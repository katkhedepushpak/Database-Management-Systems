#include <fstream>
#include <vector>
#include <string>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <cmath>
#include "classes.h"
using namespace std;

int main(int argc, char* const argv[]) {
    int i;
    BPlusTree bplus_tree;
    bplus_tree.createFromFile("Employee.csv");
	bplus_tree.saveToFile("EmployeeIndex", "DataFile");
    while (true) {
        std::cout << "Enter an Employee ID :";
        std::cin >> i; 
        if (i != -1)
        { 
        Record record = bplus_tree.findRecordById(i);
        if (record.id != -1) 
            record.print();
        else 
            cout << "Record not found." << endl;
        }
    }
    return 0;
}

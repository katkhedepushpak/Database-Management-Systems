#include <string>
#include <vector>
#include <iostream>
#include <sstream>
#include <bitset>
#include <fstream>
#include <memory>
#include <algorithm>
using namespace std;

class Record {
public:
    int id, manager_id;
    std::string bio, name;

    Record(vector<std::string> fields) {
	if (fields.size() >= 4) {
        id = stoi(fields[0]);
        name = fields[1];
        bio = fields[2];
        manager_id = stoi(fields[3]);
	} 
	else 
		throw runtime_error("Invalid record format");
	}

    void print() {
        cout << "\n\t ID: " << id << "\n";
        cout << "\t NAME: " << name << "\n";
        cout << "\t BIO: " << bio << "\n";
        cout << "\t MANAGER_ID: " << manager_id << "\n";
    }
	
	void print(ofstream& out) {
        out << id << ","<< name << ","<< bio << ","<< manager_id << "\n";
    }
};

class BPlusNode {
public:
    vector<int> keys; 
    vector<BPlusNode*> child; 
    bool is_leaf; 
    BPlusNode* parent; 
    vector<Record> records; 
    BPlusNode(bool is_leaf = false) : is_leaf(is_leaf), parent(nullptr) {}
};

class BPlusTree {
public:
    BPlusNode* root;
    int degree; 
    BPlusTree(int degree = 4) : degree(degree), root(nullptr) {}
    BPlusNode* search(int id) {
    if (!root) 
        return nullptr;
    BPlusNode* c_node = root;
    while (!c_node->is_leaf) {
        bool found = false;
        for (size_t i = 0; i < c_node->keys.size(); ++i) {
            if (id < c_node->keys[i]) {
                c_node = c_node->child[i];
                found = true;
                break;
            }
        }
        if (!found) 
            c_node = c_node->child.back();
    }

    for (size_t i = 0; i < c_node->keys.size(); ++i) {
        if (c_node->keys[i] == id) 
            return c_node;
    }
    return nullptr;
}
void insert(int id) {
    if (!root) {
        root = new BPlusNode(true);
        root->keys.push_back(id);
        return;
    }
    BPlusNode* c_node = root;
    BPlusNode* parent_node = nullptr;
    while (!c_node->is_leaf) {
        parent_node = c_node;
        bool found = false;
        for (size_t i = 0; i < c_node->keys.size(); ++i) {
            if (id < c_node->keys[i]) {
                c_node = c_node->child[i];
                found = true;
                break;
            }
        }
        if (!found)
            c_node = c_node->child.back();
    }

    if (c_node->keys.size() < degree - 1) {
        c_node->keys.push_back(id);
        sort(c_node->keys.begin(), c_node->keys.end());
    } else {
        vector<int> temp_keys = c_node->keys;
        temp_keys.push_back(id);
        sort(temp_keys.begin(), temp_keys.end());

        BPlusNode* n_node = new BPlusNode(true);
        int mid = (degree - 1) / 2;
        c_node->keys = vector<int>(temp_keys.begin(), temp_keys.begin() + mid);
        n_node->keys = vector<int>(temp_keys.begin() + mid + 1, temp_keys.end());

        if (!parent_node) {
            root = new BPlusNode(false);
            root->keys.push_back(temp_keys[mid]);
            root->child.push_back(c_node);
            root->child.push_back(n_node);
            c_node->parent = root;
            n_node->parent = root;
        } else {
            int mid_key = temp_keys[mid];
            parent_node->keys.push_back(mid_key);
            parent_node->child.push_back(n_node);
            n_node->parent = parent_node;
            sort(parent_node->keys.begin(), parent_node->keys.end());
            sort(parent_node->child.begin(), parent_node->child.end(),
                 [](const BPlusNode* lhs, const BPlusNode* rhs) {
                     return lhs->keys[0] < rhs->keys[0];
                 });
            if (parent_node->keys.size() == degree) {
                insert(parent_node->keys.back());
                parent_node->keys.pop_back();
            }
        }
    }
}
void insertRecord(Record record) {
        if (!root) {
            root = new BPlusNode(true);
            root->keys.push_back(record.id);
            root->records.push_back(record); 
            return;
        return;
        }

        BPlusNode* old_node = search(record.id);
        if (old_node) {
            for (size_t i = 0; i < old_node->keys.size(); ++i) {
                if (old_node->keys[i] == record.id) {
                    old_node->records[i] = record;
                    return;
                }
            }
        }
BPlusNode* leaf_node = old_node ? old_node : root;
    leaf_node->keys.push_back(record.id);
    leaf_node->records.push_back(record);
    sort(leaf_node->keys.begin(), leaf_node->keys.end());
}
void createFromFile(string csv_name)
    {
        ifstream file(csv_name);
        string line;
        while (getline(file, line)) {
            stringstream line_stream(line);
            vector<string> fields;
            string field;
            while (getline(line_stream, field, ',')) {
                fields.push_back(field);
            }
	
            Record record(fields);
            insertRecord(record);
      }  
        
    }

void saveToFile(string indexFile, string dataFile) {
        ofstream indexFileOut(indexFile);
        ofstream dataFileOut(dataFile);
        saveNodeToFile(root, indexFileOut, dataFileOut);
    }

Record findRecordById(int id) {
    BPlusNode* node = search(id);
    if (!node) 
        throw runtime_error("ID not found");
    for (auto& record : node->records) {
        if (record.id == id) 
            return record;
        
    }
    throw runtime_error("ID not found");
}



void saveNodeToFile(BPlusNode* node, ofstream& indexFile, ofstream& dataFile) {
        if (!node) return;

        if (node->is_leaf) {
            for (size_t i = 0; i < node->keys.size(); ++i) {
                long DF_position = dataFile.tellp();
                indexFile << node->keys[i] <<" "<< DF_position << "\n";
                node->records[i].print(dataFile);
            }
        } else {
            for (auto child : node->child) 
                saveNodeToFile(child, indexFile, dataFile);
            
        }
    }
};
